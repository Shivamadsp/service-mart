package com.project.paymentservice.model;

public enum PaymentMode {
    CASH,
    DEBIT_CARD,
    CREDIT_CARD,
    UPI,
    PAYPAL
}
