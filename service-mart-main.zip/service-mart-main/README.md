# service-mart
Contains a set of microservices for managing a backend of small e-commerce like application.
